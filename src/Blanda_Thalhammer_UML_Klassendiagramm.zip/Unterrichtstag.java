
	public enum Unterrichtstag{
		MONTAG,
		DIENSTAG,
		MITTWOCH,
		DONNERSTAG,
		FREITAG
	}