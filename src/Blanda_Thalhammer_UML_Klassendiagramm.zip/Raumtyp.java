public enum Raumtyp {
		KLASSENZIMMER,
		LABORRAUM, 
		KAFFEEHAUS;
}